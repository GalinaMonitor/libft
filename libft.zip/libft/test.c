int main()
{
	printf("%s\n", ft_itoa(2345));
	return 0;
}
